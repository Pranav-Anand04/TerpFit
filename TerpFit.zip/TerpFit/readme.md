# Workout Tracker
**Created by Pranav Anand on January 11, 2024**

## **Overview**
This project is built using **Leaflet.js** to help users log and visualize their workouts on an interactive map. It allows users to track their workout locations, encouraging them to explore new places while maintaining a consistent fitness routine.

## **Features**
- **Log different types of workouts on a map**
- **Automatically detects the user's location**
- **Allows manual selection of a specific location**
- **Input workout details:**
  - Workout Type (**Running, Cycling, etc.**)
  - **Distance covered**
  - **Duration of the workout**
  - **Calories Burned**
- **View and track all logged workouts**
- **Delete workouts using a unique ID**
- **Remove map markers by double-tapping them**

## **How It Works**
1. The app loads with an interactive map centered on the user’s location.
2. Users can manually select a specific workout location.
3. An input form appears, requiring the user to enter workout details.
4. Once submitted, the workout is logged on the map with a **unique ID**.
5. To remove a workout, users must enter the **workout ID**.
6. To delete a marker, **double-tap on it**.

## **Technology Used**
- **Leaflet.js** – For mapping and location tracking
- **JavaScript** – Handles user input and form validation
- **HTML & CSS** – Frontend structure and styling

## **Why Use This Project?**
- **Encourages users to work out in different locations**
- **Provides a visual representation of workout progress**
- **Helps users track essential workout metrics**

## **Future Improvements**
- **User authentication** to save workout history
- **Graphs and statistics** to analyze fitness progress
- **Social sharing features** to connect with others
